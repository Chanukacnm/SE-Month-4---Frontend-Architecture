import{j as t}from"./jsx-runtime-CBDCb4rg.js";import{w as E,u as m,e as b}from"./index-Dg4P7hAQ.js";import{r as u}from"./index-B-o1Wr-g.js";import{c as T}from"./cn-2dOUpm6k.js";import"./_commonjsHelpers-Cpj98o6Y.js";function p({items:n,value:a,onChange:v,label:w,className:f}){const l=u.useId(),x=u.useRef({}),r=n.filter(e=>!e.disabled),h=e=>{const o=r.findIndex(k=>k.id===a);let s=null;if(e.key==="ArrowRight"?s=(o+1)%r.length:e.key==="ArrowLeft"?s=(o-1+r.length)%r.length:e.key==="Home"?s=0:e.key==="End"&&(s=r.length-1),s===null)return;e.preventDefault();const g=r[s].id;v(g),x.current[g]?.focus()},d=n.find(e=>e.id===a);return t.jsxs("div",{className:f,children:[t.jsx("div",{role:"tablist","aria-label":w,onKeyDown:h,className:"flex gap-1 overflow-x-auto border-b border-slate-200 dark:border-slate-700",children:n.map(e=>{const o=e.id===a;return t.jsx("button",{ref:s=>{x.current[e.id]=s},type:"button",role:"tab",id:`${l}-tab-${e.id}`,"aria-selected":o,"aria-controls":`${l}-panel-${e.id}`,tabIndex:o?0:-1,disabled:e.disabled,onClick:()=>v(e.id),className:T("-mb-px whitespace-nowrap border-b-2 px-4 py-2.5 text-sm font-medium transition-colors","focus-visible:outline focus-visible:outline-2 focus-visible:-outline-offset-2 focus-visible:outline-brand-600","disabled:cursor-not-allowed disabled:opacity-50",o?"border-brand-700 text-brand-800 dark:border-brand-400 dark:text-brand-200":"border-transparent text-slate-600 hover:border-slate-300 hover:text-slate-900 dark:text-slate-400 dark:hover:text-slate-100"),children:e.label},e.id)})}),d&&t.jsx("div",{role:"tabpanel",id:`${l}-panel-${d.id}`,"aria-labelledby":`${l}-tab-${d.id}`,tabIndex:0,className:"pt-4 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600",children:d.content})]})}p.__docgenInfo={description:`WAI-ARIA Tabs pattern with automatic activation: roving tabindex,
←/→ to move, Home/End to jump. Only the active panel is rendered.`,methods:[],displayName:"Tabs",props:{items:{required:!0,tsType:{name:"Array",elements:[{name:"TabItem"}],raw:"TabItem[]"},description:""},value:{required:!0,tsType:{name:"string"},description:"Controlled: the parent owns the selected tab."},onChange:{required:!0,tsType:{name:"signature",type:"function",raw:"(id: string) => void",signature:{arguments:[{type:{name:"string"},name:"id"}],return:{name:"void"}}},description:""},label:{required:!0,tsType:{name:"string"},description:""},className:{required:!1,tsType:{name:"string"},description:""}}};const y=[{id:"overview",label:"Overview",content:t.jsx("p",{className:"text-sm",children:"Workspace overview and key numbers."})},{id:"members",label:"Members",content:t.jsx("p",{className:"text-sm",children:"Everyone with access to this workspace."})},{id:"billing",label:"Billing",content:t.jsx("p",{className:"text-sm",children:"Plan, invoices and payment methods."})},{id:"audit",label:"Audit log",content:null,disabled:!0}];function j(){const[n,a]=u.useState("overview");return t.jsxs("div",{className:"flex flex-col gap-4",children:[t.jsx(p,{label:"Workspace settings",items:y,value:n,onChange:a}),t.jsxs("p",{className:"text-xs text-slate-600 dark:text-slate-400",children:["Parent state: ",t.jsx("code",{children:n})]})]})}const N={title:"Components/Tabs",component:p},i={args:{},render:()=>t.jsx(j,{}),play:async({canvasElement:n})=>{const a=E(n);await m.click(a.getByRole("tab",{name:"Overview"})),await m.keyboard("{ArrowRight}"),await b(a.getByRole("tab",{name:"Members"})).toHaveAttribute("aria-selected","true"),await b(a.getByRole("tabpanel")).toHaveTextContent("Everyone with access"),await m.keyboard("{End}"),await b(a.getByRole("tab",{name:"Billing"})).toHaveFocus()}},c={args:{label:"Workspace settings",items:y,value:"members",onChange:()=>{}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  args: {} as never,
  render: () => <ControlledTabs />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    await userEvent.click(canvas.getByRole('tab', {
      name: 'Overview'
    }));
    await userEvent.keyboard('{ArrowRight}');
    await expect(canvas.getByRole('tab', {
      name: 'Members'
    })).toHaveAttribute('aria-selected', 'true');
    await expect(canvas.getByRole('tabpanel')).toHaveTextContent('Everyone with access');
    await userEvent.keyboard('{End}');
    await expect(canvas.getByRole('tab', {
      name: 'Billing'
    })).toHaveFocus();
  }
}`,...i.parameters?.docs?.source},description:{story:"Controlled: the parent owns `value`. Arrow keys, Home and End move between tabs.",...i.parameters?.docs?.description}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Workspace settings',
    items: ITEMS,
    value: 'members',
    onChange: () => {}
  }
}`,...c.parameters?.docs?.source}}};const H=["Controlled","SecondTabSelected"];export{i as Controlled,c as SecondTabSelected,H as __namedExportsOrder,N as default};
