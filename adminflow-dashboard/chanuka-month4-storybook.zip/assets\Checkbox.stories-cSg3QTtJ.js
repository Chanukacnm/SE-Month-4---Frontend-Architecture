import{j as e}from"./jsx-runtime-CBDCb4rg.js";import{r as d}from"./index-B-o1Wr-g.js";import{c as k}from"./cn-2dOUpm6k.js";import{e as l}from"./Field-ISmdRu-s.js";import"./_commonjsHelpers-Cpj98o6Y.js";const m=d.forwardRef(function({label:p,description:i,error:s,id:u,className:h,...f},x){const b=d.useId(),r=u??b,n=i?`${r}-desc`:void 0,g=[n,s?l(r):void 0].filter(Boolean).join(" ")||void 0;return e.jsxs("div",{className:k("flex flex-col gap-1",h),children:[e.jsxs("div",{className:"flex items-start gap-3",children:[e.jsx("input",{ref:x,id:r,type:"checkbox","aria-invalid":s?!0:void 0,"aria-describedby":g,className:"mt-0.5 h-5 w-5 shrink-0 rounded border-slate-500 accent-brand-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-brand-600 dark:accent-brand-400",...f}),e.jsxs("div",{className:"text-sm",children:[e.jsx("label",{htmlFor:r,className:"font-medium text-slate-800 dark:text-slate-200",children:p}),i&&e.jsx("p",{id:n,className:"text-slate-600 dark:text-slate-400",children:i})]})]}),s&&e.jsxs("p",{id:l(r),className:"text-sm text-red-700 dark:text-red-400",children:[e.jsx("span",{"aria-hidden":"true",children:"⚠ "}),s]})]})});m.__docgenInfo={description:"",methods:[],displayName:"Checkbox",props:{label:{required:!0,tsType:{name:"ReactNode"},description:""},description:{required:!1,tsType:{name:"ReactNode"},description:""},error:{required:!1,tsType:{name:"string"},description:""}},composes:["Omit"]};const E={title:"Components/Checkbox",component:m,args:{label:"Active account"}},t={},a={args:{defaultChecked:!0}},o={args:{description:"Inactive users can't sign in but keep their data."}},c={args:{label:"I confirm these details are correct",error:"Please confirm the details are correct"}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:"{}",...t.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  args: {
    defaultChecked: true
  }
}`,...a.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    description: "Inactive users can't sign in but keep their data."
  }
}`,...o.parameters?.docs?.source}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'I confirm these details are correct',
    error: 'Please confirm the details are correct'
  }
}`,...c.parameters?.docs?.source}}};const D=["Default","Checked","WithDescription","WithError"];export{a as Checked,t as Default,o as WithDescription,c as WithError,D as __namedExportsOrder,E as default};
