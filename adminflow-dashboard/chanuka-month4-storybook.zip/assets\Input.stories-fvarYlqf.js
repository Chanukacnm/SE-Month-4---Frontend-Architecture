import{j as d}from"./jsx-runtime-CBDCb4rg.js";import{w as u,u as m,e as l}from"./index-Dg4P7hAQ.js";import{I as y}from"./Icon-DwVzNyoy.js";import{I as w}from"./Input-Dj5hC9Jr.js";import"./index-B-o1Wr-g.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./cn-2dOUpm6k.js";import"./Field-ISmdRu-s.js";const H={title:"Components/Input",component:w,argTypes:{type:{control:"select",options:["text","email","password","search"]}},args:{label:"Full name",placeholder:"Jane Doe"},decorators:[e=>d.jsx("div",{className:"max-w-sm",children:e()})]},t={},r={args:{label:"Email",type:"email",placeholder:"name@company.com",required:!0}},s={args:{label:"Password",type:"password",placeholder:""},play:async({canvasElement:e})=>{const a=u(e),p=a.getByLabelText("Password");await m.type(p,"secret"),await l(p).toHaveAttribute("type","password"),await m.click(a.getByRole("button",{name:/show password/i})),await l(p).toHaveAttribute("type","text")}},n={args:{label:"Username",hint:"Lowercase letters and numbers only."}},o={args:{label:"Email",type:"email",defaultValue:"not-an-email",error:"Enter a valid email address, like name@company.com"},play:async({canvasElement:e})=>{const a=u(e).getByLabelText("Email");await l(a).toHaveAttribute("aria-invalid","true"),await l(a).toHaveAccessibleDescription(/valid email/i)}},c={args:{label:"Search users",hideLabel:!0,type:"search",placeholder:"Search…",leftIcon:d.jsx(y,{name:"search",size:18})}},i={args:{disabled:!0,defaultValue:"Read only value"}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:"{}",...t.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Email',
    type: 'email',
    placeholder: 'name@company.com',
    required: true
  }
}`,...r.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Password',
    type: 'password',
    placeholder: ''
  },
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const input = canvas.getByLabelText('Password');
    await userEvent.type(input, 'secret');
    await expect(input).toHaveAttribute('type', 'password');
    await userEvent.click(canvas.getByRole('button', {
      name: /show password/i
    }));
    await expect(input).toHaveAttribute('type', 'text');
  }
}`,...s.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Username',
    hint: 'Lowercase letters and numbers only.'
  }
}`,...n.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Email',
    type: 'email',
    defaultValue: 'not-an-email',
    error: 'Enter a valid email address, like name@company.com'
  },
  play: async ({
    canvasElement
  }) => {
    const input = within(canvasElement).getByLabelText('Email');
    await expect(input).toHaveAttribute('aria-invalid', 'true');
    await expect(input).toHaveAccessibleDescription(/valid email/i);
  }
}`,...o.parameters?.docs?.source}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Search users',
    hideLabel: true,
    type: 'search',
    placeholder: 'Search…',
    leftIcon: <Icon name="search" size={18} />
  }
}`,...c.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true,
    defaultValue: 'Read only value'
  }
}`,...i.parameters?.docs?.source}}};const I=["Text","Email","Password","WithHint","WithError","WithIcon","Disabled"];export{i as Disabled,r as Email,s as Password,t as Text,o as WithError,n as WithHint,c as WithIcon,I as __namedExportsOrder,H as default};
