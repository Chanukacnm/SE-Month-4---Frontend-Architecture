import{j as a}from"./jsx-runtime-CBDCb4rg.js";import{w as v,u as g,e as u,f as b}from"./index-Dg4P7hAQ.js";import{B as e}from"./Button-BYvsbsdD.js";import{I as y}from"./Icon-DwVzNyoy.js";import"./index-B-o1Wr-g.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./cn-2dOUpm6k.js";const I={title:"Components/Button",component:e,argTypes:{variant:{control:"select",options:["primary","secondary","danger","ghost"]},size:{control:"inline-radio",options:["sm","md","lg"]}},args:{onClick:b(),children:"Click me"}},n={args:{variant:"primary"}},t={args:{variant:"secondary"}},s={args:{variant:"danger",children:"Delete user"}},o={args:{variant:"ghost"}},i={args:{leftIcon:a.jsx(y,{name:"plus",size:18}),children:"Add user"}},c={args:{isLoading:!0,children:"Saving…"},play:async({canvasElement:p})=>{const r=v(p).getByRole("button");await u(r).toBeDisabled(),await u(r).toHaveAttribute("aria-busy","true")}},l={name:"Icon only (accessible name via aria-label)",args:{variant:"ghost","aria-label":"Delete user John Doe",children:a.jsx(y,{name:"trash"})}},d={play:async({args:p,canvasElement:r})=>{const h=v(r).getByRole("button");await g.tab(),await u(h).toHaveFocus(),await g.keyboard("{Enter}"),await u(p.onClick).toHaveBeenCalled()}},m={render:()=>a.jsxs("div",{className:"flex flex-wrap items-center gap-3",children:[a.jsx(e,{variant:"primary",children:"Primary"}),a.jsx(e,{variant:"secondary",children:"Secondary"}),a.jsx(e,{variant:"danger",children:"Danger"}),a.jsx(e,{variant:"ghost",children:"Ghost"}),a.jsx(e,{size:"sm",children:"Small"}),a.jsx(e,{size:"lg",children:"Large"}),a.jsx(e,{disabled:!0,children:"Disabled"})]})};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'primary'
  }
}`,...n.parameters?.docs?.source}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'secondary'
  }
}`,...t.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'danger',
    children: 'Delete user'
  }
}`,...s.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'ghost'
  }
}`,...o.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  args: {
    leftIcon: <Icon name="plus" size={18} />,
    children: 'Add user'
  }
}`,...i.parameters?.docs?.source}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  args: {
    isLoading: true,
    children: 'Saving…'
  },
  play: async ({
    canvasElement
  }) => {
    const button = within(canvasElement).getByRole('button');
    await expect(button).toBeDisabled();
    await expect(button).toHaveAttribute('aria-busy', 'true');
  }
}`,...c.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  name: 'Icon only (accessible name via aria-label)',
  args: {
    variant: 'ghost',
    'aria-label': 'Delete user John Doe',
    children: <Icon name="trash" />
  }
}`,...l.parameters?.docs?.source}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  play: async ({
    args,
    canvasElement
  }) => {
    const button = within(canvasElement).getByRole('button');
    await userEvent.tab();
    await expect(button).toHaveFocus();
    await userEvent.keyboard('{Enter}');
    await expect(args.onClick).toHaveBeenCalled();
  }
}`,...d.parameters?.docs?.source}}};m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: () => <div className="flex flex-wrap items-center gap-3">\r
      <Button variant="primary">Primary</Button>\r
      <Button variant="secondary">Secondary</Button>\r
      <Button variant="danger">Danger</Button>\r
      <Button variant="ghost">Ghost</Button>\r
      <Button size="sm">Small</Button>\r
      <Button size="lg">Large</Button>\r
      <Button disabled>Disabled</Button>\r
    </div>
}`,...m.parameters?.docs?.source}}};const E=["Primary","Secondary","Danger","Ghost","WithIcon","Loading","IconOnly","KeyboardActivation","AllVariants"];export{m as AllVariants,s as Danger,o as Ghost,l as IconOnly,d as KeyboardActivation,c as Loading,n as Primary,t as Secondary,i as WithIcon,E as __namedExportsOrder,I as default};
