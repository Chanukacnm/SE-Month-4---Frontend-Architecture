import{j as r}from"./jsx-runtime-CBDCb4rg.js";import{r as h}from"./index-B-o1Wr-g.js";import{c as j}from"./cn-2dOUpm6k.js";import{F as q,c as M,d as A}from"./Field-ISmdRu-s.js";import"./_commonjsHelpers-Cpj98o6Y.js";const g=h.forwardRef(function({label:y,options:v,hint:u,error:a,hideLabel:E,placeholder:S,containerClassName:T,className:R,id:D,multiple:t,required:c,...N},x){const C=h.useId(),p=D??C,b=t?"Hold Ctrl (Cmd on Mac) to select more than one.":void 0,f=u||b?[u,b].filter(Boolean).join(" "):void 0;return r.jsx(q,{id:p,label:y,hint:f,error:a,required:c,hideLabel:E,className:T,children:r.jsxs("select",{ref:x,id:p,multiple:t,required:c,"aria-required":c||void 0,"aria-invalid":a?!0:void 0,"aria-describedby":A(p,f,a),className:j(M(!!a),t?"py-2":"h-10 pr-8",R),...N,children:[S&&!t&&r.jsx("option",{value:"",disabled:!0,children:S}),v.map(s=>r.jsx("option",{value:s.value,disabled:s.disabled,children:s.label},s.value))]})})});g.__docgenInfo={description:"Native <select> — gets keyboard, screen reader and mobile picker support for free.\nPass `multiple` for multi-select (Ctrl/Cmd/Shift + click, or Space with arrow keys).",methods:[],displayName:"Select",props:{label:{required:!0,tsType:{name:"ReactNode"},description:""},options:{required:!0,tsType:{name:"ReadonlyArray",elements:[{name:"SelectOption"}],raw:"ReadonlyArray<SelectOption>"},description:""},hint:{required:!1,tsType:{name:"ReactNode"},description:""},error:{required:!1,tsType:{name:"string"},description:""},hideLabel:{required:!1,tsType:{name:"boolean"},description:""},placeholder:{required:!1,tsType:{name:"string"},description:"Renders a disabled first option, useful when there is no sensible default."},containerClassName:{required:!1,tsType:{name:"string"},description:""}},composes:["Omit"]};const P=[{value:"admin",label:"Admin"},{value:"editor",label:"Editor"},{value:"user",label:"User"}],m=["Engineering","Sales","Marketing","Support","Finance","Operations"].map(e=>({value:e,label:e})),_={title:"Components/Select",component:g,args:{label:"Role",options:P},decorators:[e=>r.jsx("div",{className:"max-w-sm",children:e()})]},o={},n={args:{label:"Department",options:m,placeholder:"Select a department",defaultValue:""}},l={args:{label:"Departments",options:m,multiple:!0,defaultValue:["Sales","Support"],size:6}},i={args:{label:"Department",options:m,placeholder:"Select a department",defaultValue:"",error:"Choose a department",required:!0}},d={args:{disabled:!0}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:"{}",...o.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Department',
    options: DEPARTMENTS,
    placeholder: 'Select a department',
    defaultValue: ''
  }
}`,...n.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Departments',
    options: DEPARTMENTS,
    multiple: true,
    defaultValue: ['Sales', 'Support'],
    size: 6
  } as never
}`,...l.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  args: {
    label: 'Department',
    options: DEPARTMENTS,
    placeholder: 'Select a department',
    defaultValue: '',
    error: 'Choose a department',
    required: true
  }
}`,...i.parameters?.docs?.source}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  args: {
    disabled: true
  }
}`,...d.parameters?.docs?.source}}};const B=["Single","WithPlaceholder","MultiSelect","WithError","Disabled"];export{d as Disabled,l as MultiSelect,o as Single,i as WithError,n as WithPlaceholder,B as __namedExportsOrder,_ as default};
