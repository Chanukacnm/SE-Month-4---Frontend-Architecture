import{j as e}from"./jsx-runtime-CBDCb4rg.js";import{f as x}from"./index-Dg4P7hAQ.js";import{c as p}from"./cn-2dOUpm6k.js";import{I as g}from"./Icon-DwVzNyoy.js";import"./index-B-o1Wr-g.js";import"./_commonjsHelpers-Cpj98o6Y.js";const v={info:{box:"border-sky-300 bg-sky-50 text-sky-900 dark:border-sky-700 dark:bg-sky-950 dark:text-sky-100",icon:"info",label:"Information"},success:{box:"border-emerald-300 bg-emerald-50 text-emerald-900 dark:border-emerald-700 dark:bg-emerald-950 dark:text-emerald-100",icon:"check",label:"Success"},warning:{box:"border-amber-300 bg-amber-50 text-amber-900 dark:border-amber-700 dark:bg-amber-950 dark:text-amber-100",icon:"warning",label:"Warning"},error:{box:"border-red-300 bg-red-50 text-red-900 dark:border-red-700 dark:bg-red-950 dark:text-red-100",icon:"error",label:"Error"}};function r({variant:a="info",title:c,children:m,onDismiss:u,assertive:b,className:f}){const d=v[a],h=b??(a==="error"||a==="warning");return e.jsxs("div",{role:h?"alert":"status",className:p("flex gap-3 rounded-lg border p-4 text-sm",d.box,f),children:[e.jsx(g,{name:d.icon,className:"mt-0.5 shrink-0"}),e.jsxs("div",{className:"flex-1",children:[e.jsxs("span",{className:"sr-only",children:[d.label,": "]}),c&&e.jsx("p",{className:"font-semibold",children:c}),m&&e.jsx("div",{className:p(c&&"mt-1"),children:m})]}),u&&e.jsx("button",{type:"button",onClick:u,"aria-label":"Dismiss",className:"-m-1 h-8 w-8 shrink-0 rounded-md p-1.5 hover:bg-black/5 focus-visible:outline focus-visible:outline-2 focus-visible:outline-current dark:hover:bg-white/10",children:e.jsx(g,{name:"close",size:18})})]})}r.__docgenInfo={description:"Status message. Colour is never the only signal: each variant has an icon and a hidden text label.",methods:[],displayName:"Alert",props:{variant:{required:!1,tsType:{name:"NotificationKind"},description:"",defaultValue:{value:"'info'",computed:!1}},title:{required:!1,tsType:{name:"ReactNode"},description:""},children:{required:!1,tsType:{name:"ReactNode"},description:""},onDismiss:{required:!1,tsType:{name:"signature",type:"function",raw:"() => void",signature:{arguments:[],return:{name:"void"}}},description:""},assertive:{required:!1,tsType:{name:"boolean"},description:'Interrupting announcement (role="alert") vs polite (role="status"). Defaults by variant.'},className:{required:!1,tsType:{name:"string"},description:""}}};const A={title:"Components/Alert",component:r,argTypes:{variant:{control:"select",options:["info","success","warning","error"]}},args:{title:"Heads up",children:"Something you should know about."},decorators:[a=>e.jsx("div",{className:"max-w-lg",children:a()})]},s={args:{variant:"info",title:"Scheduled maintenance",children:"The dashboard will be read-only on Sunday 02:00–03:00 UTC."}},n={args:{variant:"success",title:"User created",children:"Priya Nair was added to Engineering."}},t={args:{variant:"warning",title:"Seat limit almost reached",children:"23 of 25 seats are in use."}},i={args:{variant:"error",title:"Could not save changes",children:"A user with this email already exists."}},o={args:{variant:"info",onDismiss:x()}},l={render:()=>e.jsxs("div",{className:"flex flex-col gap-3",children:[e.jsx(r,{variant:"info",title:"Info"}),e.jsx(r,{variant:"success",title:"Success"}),e.jsx(r,{variant:"warning",title:"Warning"}),e.jsx(r,{variant:"error",title:"Error"})]})};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'info',
    title: 'Scheduled maintenance',
    children: 'The dashboard will be read-only on Sunday 02:00–03:00 UTC.'
  }
}`,...s.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'success',
    title: 'User created',
    children: 'Priya Nair was added to Engineering.'
  }
}`,...n.parameters?.docs?.source}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'warning',
    title: 'Seat limit almost reached',
    children: '23 of 25 seats are in use.'
  }
}`,...t.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'error',
    title: 'Could not save changes',
    children: 'A user with this email already exists.'
  }
}`,...i.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  args: {
    variant: 'info',
    onDismiss: fn()
  }
}`,...o.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: () => <div className="flex flex-col gap-3">\r
      <Alert variant="info" title="Info" />\r
      <Alert variant="success" title="Success" />\r
      <Alert variant="warning" title="Warning" />\r
      <Alert variant="error" title="Error" />\r
    </div>
}`,...l.parameters?.docs?.source}}};const T=["Info","Success","Warning","Error","Dismissible","AllVariants"];export{l as AllVariants,o as Dismissible,i as Error,s as Info,n as Success,t as Warning,T as __namedExportsOrder,A as default};
