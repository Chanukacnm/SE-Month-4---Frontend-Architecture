import{j as e}from"./jsx-runtime-CBDCb4rg.js";import{B as r}from"./Badge-CGygV5YP.js";import"./index-B-o1Wr-g.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./cn-2dOUpm6k.js";const i={title:"Components/Badge",component:r,argTypes:{tone:{control:"select",options:["neutral","brand","success","warning","danger"]}},args:{children:"Active",tone:"success"}},n={},a={render:()=>e.jsxs("div",{className:"flex gap-2",children:[e.jsx(r,{tone:"neutral",children:"User"}),e.jsx(r,{tone:"brand",children:"Admin"}),e.jsx(r,{tone:"success",children:"Active"}),e.jsx(r,{tone:"warning",children:"Inactive"}),e.jsx(r,{tone:"danger",children:"Deleted"})]})};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:"{}",...n.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  render: () => <div className="flex gap-2">\r
      <Badge tone="neutral">User</Badge>\r
      <Badge tone="brand">Admin</Badge>\r
      <Badge tone="success">Active</Badge>\r
      <Badge tone="warning">Inactive</Badge>\r
      <Badge tone="danger">Deleted</Badge>\r
    </div>
}`,...a.parameters?.docs?.source}}};const l=["Playground","AllTones"];export{a as AllTones,n as Playground,l as __namedExportsOrder,i as default};
