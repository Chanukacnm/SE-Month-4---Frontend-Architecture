import{j as e}from"./jsx-runtime-CBDCb4rg.js";import{B as C}from"./Badge-CGygV5YP.js";import{B as l}from"./Button-BYvsbsdD.js";import{c as i}from"./cn-2dOUpm6k.js";import"./index-B-o1Wr-g.js";import"./_commonjsHelpers-Cpj98o6Y.js";function c({className:s,as:a="section",...d}){return e.jsx(a,{className:i("flex flex-col rounded-xl border border-slate-200 bg-white shadow-sm dark:border-slate-700 dark:bg-slate-900",s),...d})}function B({title:s,subtitle:a,actions:d,level:m=2,titleId:p,className:x,...u}){const y=`h${m}`;return e.jsxs("div",{className:i("flex items-start justify-between gap-4 border-b border-slate-200 px-5 py-4 dark:border-slate-700",x),...u,children:[e.jsxs("div",{children:[e.jsx(y,{id:p,className:"text-base font-semibold text-slate-900 dark:text-white",children:s}),a&&e.jsx("p",{className:"mt-0.5 text-sm text-slate-600 dark:text-slate-400",children:a})]}),d&&e.jsx("div",{className:"flex shrink-0 items-center gap-2",children:d})]})}function j({className:s,...a}){return e.jsx("div",{className:i("flex-1 px-5 py-4",s),...a})}function h({className:s,...a}){return e.jsx("div",{className:i("flex items-center justify-end gap-2 border-t border-slate-200 px-5 py-3 dark:border-slate-700",s),...a})}const r=Object.assign(c,{Header:B,Body:j,Footer:h});c.__docgenInfo={description:`Compound component: <Card><Card.Header title="…" /><Card.Body>…</Card.Body><Card.Footer>…</Card.Footer></Card>
Each slot owns its own spacing and borders, so consumers only compose.`,methods:[],displayName:"CardRoot",props:{as:{required:!1,tsType:{name:"union",raw:"'section' | 'article' | 'div'",elements:[{name:"literal",value:"'section'"},{name:"literal",value:"'article'"},{name:"literal",value:"'div'"}]},description:"",defaultValue:{value:"'section'",computed:!1}}}};const w={title:"Components/Card",component:r,decorators:[s=>e.jsx("div",{className:"max-w-md",children:s()})]},t={render:()=>e.jsxs(r,{children:[e.jsx(r.Header,{title:"Team plan",subtitle:"Billed monthly",actions:e.jsx(C,{tone:"success",children:"Active"})}),e.jsx(r.Body,{children:e.jsx("p",{className:"text-sm text-slate-700 dark:text-slate-300",children:"25 seats · 18 in use. Next invoice on 1 November 2026."})}),e.jsxs(r.Footer,{children:[e.jsx(l,{variant:"secondary",size:"sm",children:"Manage seats"}),e.jsx(l,{size:"sm",children:"Upgrade"})]})]})},o={render:()=>e.jsx(r,{children:e.jsx(r.Body,{children:e.jsx("p",{className:"text-sm",children:"A minimal card with just a body slot."})})})},n={render:()=>e.jsxs(r,{children:[e.jsx(r.Header,{title:"Recent activity"}),e.jsx(r.Body,{children:e.jsxs("ul",{className:"list-disc pl-5 text-sm",children:[e.jsx("li",{children:"Alex invited Priya"}),e.jsx("li",{children:"Erin updated Ben's role"})]})})]})};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: () => <Card>\r
      <Card.Header title="Team plan" subtitle="Billed monthly" actions={<Badge tone="success">Active</Badge>} />\r
      <Card.Body>\r
        <p className="text-sm text-slate-700 dark:text-slate-300">25 seats · 18 in use. Next invoice on 1 November 2026.</p>\r
      </Card.Body>\r
      <Card.Footer>\r
        <Button variant="secondary" size="sm">\r
          Manage seats\r
        </Button>\r
        <Button size="sm">Upgrade</Button>\r
      </Card.Footer>\r
    </Card>
}`,...t.parameters?.docs?.source},description:{story:"Compound component: Card.Header, Card.Body and Card.Footer are composed freely.",...t.parameters?.docs?.description}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: () => <Card>\r
      <Card.Body>\r
        <p className="text-sm">A minimal card with just a body slot.</p>\r
      </Card.Body>\r
    </Card>
}`,...o.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  render: () => <Card>\r
      <Card.Header title="Recent activity" />\r
      <Card.Body>\r
        <ul className="list-disc pl-5 text-sm">\r
          <li>Alex invited Priya</li>\r
          <li>Erin updated Ben's role</li>\r
        </ul>\r
      </Card.Body>\r
    </Card>
}`,...n.parameters?.docs?.source}}};const F=["HeaderBodyFooter","BodyOnly","HeaderAndBody"];export{o as BodyOnly,n as HeaderAndBody,t as HeaderBodyFooter,F as __namedExportsOrder,w as default};
