import{j as a}from"./jsx-runtime-CBDCb4rg.js";import{r as p}from"./index-B-o1Wr-g.js";import{P as t}from"./Pagination-hCTd2FIW.js";import"./_commonjsHelpers-Cpj98o6Y.js";import"./cn-2dOUpm6k.js";import"./Icon-DwVzNyoy.js";function n({totalPages:s}){const[o,m]=p.useState(1);return a.jsx(t,{page:o,totalPages:s,onPageChange:m,summary:`Page ${o} of ${s}`})}const x={title:"Components/Pagination",component:t},e={args:{},render:()=>a.jsx(n,{totalPages:5})},r={args:{},render:()=>a.jsx(n,{totalPages:14})};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  args: {} as never,
  render: () => <Demo totalPages={5} />
}`,...e.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  args: {} as never,
  render: () => <Demo totalPages={14} />
}`,...r.parameters?.docs?.source}}};const l=["FewPages","ManyPages"];export{e as FewPages,r as ManyPages,l as __namedExportsOrder,x as default};
