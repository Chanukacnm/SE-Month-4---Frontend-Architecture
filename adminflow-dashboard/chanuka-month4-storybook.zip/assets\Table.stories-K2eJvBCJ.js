import{j as t}from"./jsx-runtime-CBDCb4rg.js";import{w as T,e as x,u as k}from"./index-Dg4P7hAQ.js";import{r as v}from"./index-B-o1Wr-g.js";import{B as P}from"./Badge-CGygV5YP.js";import{c as d}from"./cn-2dOUpm6k.js";import{I as C}from"./Icon-DwVzNyoy.js";import{P as R}from"./Pagination-hCTd2FIW.js";import"./_commonjsHelpers-Cpj98o6Y.js";const A=(e,a)=>e?a==="asc"?"ascending":"descending":"none";function w({caption:e,hideCaption:a,columns:o,rows:l,rowKey:m,sort:s,onSortChange:u,pagination:c,isLoading:i,emptyState:y="No results",className:b}){const N=r=>{const n=s?.key===r&&s.direction==="asc"?"desc":"asc";u?.({key:r,direction:n})};return t.jsxs("div",{className:d("flex flex-col gap-4",b),children:[t.jsxs("div",{className:"relative overflow-x-auto rounded-xl border border-slate-200 dark:border-slate-700",tabIndex:0,role:"region","aria-label":"Scrollable table",children:[i&&t.jsx("div",{"aria-hidden":"true",className:"absolute inset-x-0 top-0 h-1 overflow-hidden",children:t.jsx("div",{className:"h-full w-1/3 animate-[loading-bar_1s_ease-in-out_infinite] bg-brand-600 motion-reduce:w-full motion-reduce:animate-pulse dark:bg-brand-400"})}),t.jsxs("table",{className:"min-w-full divide-y divide-slate-200 text-left text-sm dark:divide-slate-700","aria-busy":i||void 0,children:[t.jsx("caption",{className:d("px-4 py-3 text-left text-sm font-medium text-slate-700 dark:text-slate-300",a&&"sr-only"),children:e}),t.jsx("thead",{className:"bg-slate-50 dark:bg-slate-800/60",children:t.jsx("tr",{children:o.map(r=>{const n=s?.key===r.key;return t.jsx("th",{scope:"col","aria-sort":r.sortable?A(n,s?.direction??"asc"):void 0,className:d("whitespace-nowrap px-4 py-3 font-semibold text-slate-700 dark:text-slate-200",r.headerClassName),children:r.sortable&&u?t.jsxs("button",{type:"button",onClick:()=>N(r.key),className:"-mx-1 inline-flex items-center gap-1 rounded px-1 hover:text-brand-700 focus-visible:outline focus-visible:outline-2 focus-visible:outline-brand-600 dark:hover:text-brand-300",children:[r.header,t.jsx(C,{name:n?s.direction==="asc"?"chevronUp":"chevronDown":"sort",size:14,className:n?"":"opacity-60"})]}):r.header},r.key)})})}),t.jsx("tbody",{className:d("divide-y divide-slate-200 bg-white dark:divide-slate-800 dark:bg-slate-900"),children:l.length===0?t.jsx("tr",{children:t.jsx("td",{colSpan:o.length,className:"px-4 py-10 text-center text-slate-600 dark:text-slate-400",children:y})}):l.map(r=>t.jsx("tr",{className:"hover:bg-slate-50 dark:hover:bg-slate-800/50",children:o.map(n=>{const j=n.isRowHeader?"th":"td";return t.jsx(j,{scope:n.isRowHeader?"row":void 0,className:d("px-4 py-3 align-middle font-normal text-slate-800 dark:text-slate-200",n.className),children:n.cell(r)},n.key)})},m(r)))})]})]}),c&&c.totalPages>0&&t.jsx(R,{...c})]})}w.__docgenInfo={description:`Data table with sortable column headers (buttons inside <th>, state exposed
through aria-sort) and optional pagination. Generic over the row type.`,methods:[],displayName:"Table",props:{caption:{required:!0,tsType:{name:"ReactNode"},description:""},hideCaption:{required:!1,tsType:{name:"boolean"},description:"Visually hide the caption while keeping it for screen readers."},columns:{required:!0,tsType:{name:"Array",elements:[{name:"Column",elements:[{name:"T"}],raw:"Column<T>"}],raw:"Column<T>[]"},description:""},rows:{required:!0,tsType:{name:"Array",elements:[{name:"T"}],raw:"T[]"},description:""},rowKey:{required:!0,tsType:{name:"signature",type:"function",raw:"(row: T) => string",signature:{arguments:[{type:{name:"T"},name:"row"}],return:{name:"string"}}},description:""},sort:{required:!1,tsType:{name:"SortState"},description:""},onSortChange:{required:!1,tsType:{name:"signature",type:"function",raw:"(sort: SortState) => void",signature:{arguments:[{type:{name:"SortState"},name:"sort"}],return:{name:"void"}}},description:""},pagination:{required:!1,tsType:{name:"PaginationProps"},description:""},isLoading:{required:!1,tsType:{name:"boolean"},description:""},emptyState:{required:!1,tsType:{name:"ReactNode"},description:"",defaultValue:{value:"'No results'",computed:!1}},className:{required:!1,tsType:{name:"string"},description:""}}};const S=Array.from({length:23},(e,a)=>({id:String(a+1),name:["Amara Perera","Ben Smith","Chen Wang","Dilan Silva","Elena Garcia","Farah Khan"][a%6]+` ${a+1}`,email:`user${a+1}@example.com`,role:["admin","editor","user"][a%3],joined:new Date(Date.UTC(2026,a%12,a%27+1)).toISOString().slice(0,10)})),f=[{key:"name",header:"Name",sortable:!0,isRowHeader:!0,cell:e=>e.name},{key:"email",header:"Email",sortable:!0,cell:e=>e.email},{key:"role",header:"Role",cell:e=>t.jsx(P,{tone:e.role==="admin"?"brand":"neutral",children:e.role})},{key:"joined",header:"Joined",sortable:!0,cell:e=>e.joined}];function H({pageSize:e=5}){const[a,o]=v.useState({key:"name",direction:"asc"}),[l,m]=v.useState(1),s=v.useMemo(()=>{const i=a.key;return[...S].sort((y,b)=>y[i].localeCompare(b[i])*(a.direction==="asc"?1:-1))},[a]),u=Math.ceil(s.length/e),c=s.slice((l-1)*e,l*e);return t.jsx(w,{caption:"Team members",columns:f,rows:c,rowKey:i=>i.id,sort:a,onSortChange:i=>{o(i),m(1)},pagination:{page:l,totalPages:u,onPageChange:m,summary:`Showing ${(l-1)*e+1}–${Math.min(l*e,s.length)} of ${s.length}`}})}const I={title:"Components/Table",component:w},p={args:{},render:()=>t.jsx(H,{}),play:async({canvasElement:e})=>{const a=T(e),o=a.getByRole("columnheader",{name:/name/i});await x(o).toHaveAttribute("aria-sort","ascending"),await k.click(T(o).getByRole("button")),await x(o).toHaveAttribute("aria-sort","descending"),await k.click(a.getByRole("button",{name:"Page 2"})),await x(a.getByRole("button",{name:"Page 2"})).toHaveAttribute("aria-current","page")}},g={args:{caption:"Team members",columns:f,rows:[],rowKey:e=>e,emptyState:"No users match your search."}},h={args:{caption:"Team members",columns:f,rows:S.slice(0,5),rowKey:e=>e.id,isLoading:!0}};p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  args: {} as never,
  render: () => <SortablePaginatedTable />,
  play: async ({
    canvasElement
  }) => {
    const canvas = within(canvasElement);
    const nameHeader = canvas.getByRole('columnheader', {
      name: /name/i
    });
    await expect(nameHeader).toHaveAttribute('aria-sort', 'ascending');
    await userEvent.click(within(nameHeader).getByRole('button'));
    await expect(nameHeader).toHaveAttribute('aria-sort', 'descending');
    await userEvent.click(canvas.getByRole('button', {
      name: 'Page 2'
    }));
    await expect(canvas.getByRole('button', {
      name: 'Page 2'
    })).toHaveAttribute('aria-current', 'page');
  }
}`,...p.parameters?.docs?.source}}};g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  args: {
    caption: 'Team members',
    columns: COLUMNS as never,
    rows: [],
    rowKey: (r: never) => r,
    emptyState: 'No users match your search.'
  } as never
}`,...g.parameters?.docs?.source}}};h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  args: {
    caption: 'Team members',
    columns: COLUMNS as never,
    rows: DATA.slice(0, 5) as never,
    rowKey: ((r: Row) => r.id) as never,
    isLoading: true
  } as never
}`,...h.parameters?.docs?.source}}};const O=["SortableWithPagination","Empty","Loading"];export{g as Empty,h as Loading,p as SortableWithPagination,O as __namedExportsOrder,I as default};
